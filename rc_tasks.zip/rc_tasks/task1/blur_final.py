import numpy as np
from PIL import Image
import matplotlib.image as mp
img=np.array(Image.open('hills.jpg'))
dupImg=np.array(Image.open('hills.jpg'))
dim=img.shape
n=3         #amount
i=n//2
while i<dim[0]-n//2:
    j=n//2
    while j<dim[1]-n//2:
        r=[0,0,0]
        k1=i-n//2
        while k1<=i+(n//2):
            k2=j-n//2
            while k2<=j+(n//2):
                r+=img[k1,k2]
                k2+=1
            k1+=1
        r=r/(n*n)
        r[0]=round(r[0])
        r[1]=round(r[1])
        r[2]=round(r[2])
        dupImg[i,j,:]=r[:]
        j+=1
    i+=1
mp.imsave("BLUR_HILLS.jpg", dupImg)