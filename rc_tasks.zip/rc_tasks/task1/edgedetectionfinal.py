import numpy as np
from PIL import Image
import matplotlib.image as mp
import math
import cv2 as cv
img=np.array(Image.open('flower.jpg'))
dim=img.shape
kernelX=np.array([
    [1,0,-1],
    [2,0,-2],
    [1,0,-1]
])
kernelY=np.array([
    [-1,-2,-1],
    [0,0,0],
    [1,2,1]
])
a=np.empty([3,3])
def edge(img,kernel):
    i=1
    j=1
    dim=img.shape
    dupimg=np.array(Image.open('flower.jpg'))
    while(i<dim[0]-1):
        while(j<dim[1]-1):
            k1=i-1
            while k1<=i+1:
                k2=j-1
                while k2<=j+1:
                    a=img[k1,k2,[0,1,2]]
                    a=a*kernel
                    k2=k2+1
                k1=k1+1
            dupimg[i,j,:]=round(a.sum())
            j+=1
        i+=1
    return dupimg
h=edge(img,kernelX)
v=edge(img,kernelY)
f=h**2+v**2
f=f**0.5
final=f.reshape(-1)

for i in range(len(final)):
    final[i]=int(final[i])
final=final.reshape(dim[0],dim[1],3)
cv.imwrite("edge detected.jpg",final)