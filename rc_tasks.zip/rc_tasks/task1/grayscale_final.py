import numpy as np
from PIL import Image
import matplotlib.image as mp
img=np.array(Image.open('bees.jpg'))
dup=np.array(Image.open('bees.jpg'))
dim=img.shape
for i in range(dim[0]):
    for j in range(dim[1]):
        r,g,b=img[i,j,0:3]
        gray = r * 0.299 + g * 0.587 + b * 0.114
        gray = int(gray)
        dup[i,j,:]=gray
mp.imsave("grayscaled.jpg", dup)