#was close to completing the task but was facing difficulties to write the scanned images to the main o/p variable
import PIL
from PIL import Image
from PIL import ImageChops
import pathlib
import math
import cv2 as cv
#changes made: used a dummy variable to return the scan
## Here we load the world map that you need to recreate.
image = Image.open(pathlib.Path('worldmap.jpg'))
image = image.convert('1')
image.thumbnail((400, 400))
image_size = min(image.size)
image2 = Image.new(mode="1", size=(400,400))
dummy = Image.new(mode="1", size=(400,400))
no_of_rays = 360


def func(image,dummy,centerX,centerY):#LIDAR
    dummy = Image.new(mode="1", size=(400,400))
    if image.getpixel((centerX, centerY)) == 0:
        print('invalid')
    else:
        for i in range(0,360,int(360/no_of_rays)):
            r = 0

            currentX = round(centerX + r*math.cos(i*math.pi/180))
            currentY = round(centerY + r*math.sin(i*math.pi/180))

            while ((currentX < image_size and currentX >= 0) and (currentY < image_size and currentY >=0) and (image.getpixel((currentX, currentY)) != 0)):
                currentX = round(centerX + r*math.cos(i*math.pi/180))
                currentY = round(centerY + r*math.sin(i*math.pi/180))
                dummy.putpixel(((currentX-centerX)%400,(currentY-centerY)%400),255)# we do %400 so as to not go over the max index
                r+=1
    return dummy


def isEdge(centerX,centerY):#we only need to scan along the edges and overlap them
    if image.getpixel((centerX,centerY))!=0 and (image.getpixel(((centerX+1)%400,(centerY)%400))==0 or image.getpixel(((centerX)%400,(centerY+1)%400))==0 or image.getpixel(((centerX-1)%400,(centerY)%400))==0 or image.getpixel(((centerX)%400,(centerY-1)%400))==0):
        return 1
    else:
        return 0
    

#now, we go over the image and only take scan if necessary i.e., when we are at an edge.
#a sample of the scan taken at any coordinate can be seen in test2.py file attached



centerX=0
y=(0,0,399,399)
while centerX<400:
    centerY=0
    while centerY<400:
        if isEdge(centerX,centerY)==1:
            dummy=func(image,dummy,centerX,centerY)
            dummy=ImageChops.offset(image2, xoffset=centerX, yoffset=centerY)
            image2=ImageChops.add(image2,dummy,2.0)
            i=0
            while i<400:
                j=0
                while j<400:
                    image2.putpixel((i,j),image2.getpixel((i,j)))
                    j+=1
                i+=1
        centerY+=1
    centerX+=1
image2.show()
image.show()